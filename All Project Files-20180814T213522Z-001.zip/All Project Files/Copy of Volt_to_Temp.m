function [ Temp ] = Volt_to_Temp( V , Fixed_Resistor )
%Volt_to_Temp Converts voltage read by arduino to temperature
%   Use voltage dividing eq to calc resistance then use steinhardt
%   coefs to calc temperature

% Coefficients for Thermistor
coef = [0.00116741481796827,0.000227371846448138,1.19663032602201e-07];

% Voltage divider Eq.
Resistance  = (V ./ (5 - V)) .* Fixed_Resistor;

% Use steinhardt coefs to find temp and convert K to C
Temperature = 1./(coef(1) + coef(2).*log(Resistance) + coef(3).*(log(Resistance).^3));
Temp = Temperature - 273.15; % Convert from K to C

end

