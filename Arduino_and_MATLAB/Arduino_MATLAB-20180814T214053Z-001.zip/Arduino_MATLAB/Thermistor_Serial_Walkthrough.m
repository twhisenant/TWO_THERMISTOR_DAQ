% Thermistor_Movie_2.m
% 8/7/2018
% MATLAB 2016b
%
% Read serial feed from Ardy Arduino, live-plot,
% save figure and data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Clear Workspace
clear all
close all
clc

% Reset all External Instruments
instrreset

% Create a Serial Object
Ardy = serial('/dev/cu.usbserial-DA01MF04');
fopen(Ardy);

% Set Pins to corresponding resistance (10k Ohms)
Resistor_Array = [10000 10000];

% Set Pause Between Loops
wait = 1; %1 second

% Set Number of Loops
N_loops = 30;

% Set Up the Plot
hold on
grid on
title('2-Thermistor Data','Fontsize',16);
xlabel('Time (s)','Fontsize',14);
ylabel('Temperature (C)','Fontsize',14);

% Set Axis
axis([0 N_loops 15 40])

% Start Timer
tic

% Main Read Loop

for i=1:N_loops
    
    % Timestamp for pause time, not data
    loop_begin = toc;
    
    % Read the serial feed
    Temp_Array(i,[1:3]) = fscanf(Ardy,'%f,%f,%f');
    
        % Convert millis to seconds
        Temp_Array(i,1) = Temp_Array(i,1)/1000;
        
    % Live-Plot the Data
    plot(Temp_Array(i,1),Temp_Array(i,2),'oblue')
    plot(Temp_Array(i,1),Temp_Array(i,3),'+red')
    
    % Pause Between each loop so total_time = 1 second
    loop_end = toc;
    pause(wait - (loop_end - loop_begin))
    
end

% print figure and save data
   print('2_Thermistor_Serial_DAQ','-dpng','-r300')
   save 2_Thermistor_Serial_DATA Temp_Array
   
   % DONE!
 
  