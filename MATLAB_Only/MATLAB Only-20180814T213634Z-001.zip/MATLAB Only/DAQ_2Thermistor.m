% DAQ_2Thermistor
% Measure analog input on Arduino Uno (2 Channels), then convert to
% temperature. If diff in temp > 5 deg, turn on LED

% 5-Thermistor Script: measure the voltage difference and convert to
% resistance and then temperature from five thermistors

% Clear Workspace
clear all 
close all
clc

% Instantiate Arduino
Ardy = arduino('/dev/cu.usbserial-DA01MF04', 'uno');

% Set Pins with Corresponding Resistances
Resistor_Array = [10000 10000];

% Set Constant Pause and TimeLimit
 wait      = 1;
 TimeLimit = 5;
 N_loops   = 30;

% Set up the plot
axis([0 N_loops 15 40])
    hold on
    grid on
title('Whisenant 2-Thermistor Data','Fontsize',16)
ylabel('Temperature (C)','Fontsize',14)
xlabel('Time (s)','Fontsize',14)
symcol = {'ob' '+r'};
for q = 1:2
  h(q) = plot(NaN,NaN,symcol{q});
end
legend(h,'Resistor 1','Resistor 2')


% Start Timer 
tic   

% For Loop over index i
for i = 1:N_loops
        
        %Read Timer
            t = toc;

        %Read the voltage and convert to temperature
            V_A(1) = readVoltage(Ardy, 'A0'); 
            V_A(2) = readVoltage(Ardy, 'A1');
            
        % Create Data Matrix
            Temp_Array(i,2:3) = Volt_to_Temp( V_A , Resistor_Array );
            Temp_Array(i,1) = t;
            
        % Turn LED ON if Temp Difference > 3 Deg C
            if abs(Temp_Array(i,2) - Temp_Array(i,3)) > 3
                writeDigitalPin(Ardy,'D5',1);
            else
                writeDigitalPin(Ardy,'D5',0);
            end
        
        % Live-plot of Data
            plot(t, Temp_Array(i,2),'oblue','MarkerSize',8,'LineWidth',2);
            plot(t, Temp_Array(i,3),'+red','MarkerSize',8,'LineWidth',2);
                
        % Pause between loops (enough to make each loop 1 sec long) 
            loop_end = toc;
            pause(wait - (loop_end - t))
            


        % Break loop if TimeLimit is reached
            if toc/60>TimeLimit

                 disp(['Time Limit Reached'])
                 break

            end
    
end

    
% Reformat Axes, Label, and Save
 figure(1)
    xlim([min(Temp_Array(:,1)) max(Temp_Array(:,1))]);   
    AxisFind = Temp_Array(:,2:3);
    AxisFind = AxisFind(AxisFind > 0);
    AxisLow = min(AxisFind(:))-5;
    AxisHigh = max(AxisFind(:))+5;
    ylim([AxisLow AxisHigh]);
    
    title(['Whisenant 2-Thermistor Data; N =' num2str(i) ' Total Time = '...
    num2str(round(loop_end/60,1)) 'min'])
    ylabel('Temperature (C)','Fontsize',14)
    xlabel('Time (s)','Fontsize',14)
    lego = legend('Therm 1','Therm 2',...
        'location','northeast');
        lego.FontSize = 14;
   
    print('2_Thermistor_DAQ','-dpng','-r300')
    
    
    
    